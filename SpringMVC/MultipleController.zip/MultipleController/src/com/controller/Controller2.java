package com.controller;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Controller2 {
	@RequestMapping("/View2")
	public String show(){
		return "View2";
	}
}
