package pkg;

import java.io.Serializable;

public class LoginBean implements Serializable {
	private String Uname,pword;

	public String getUname() {
		return Uname;
	}

	public String getPword() {
		return pword;
	}

	public void setUname(String uname) {
		Uname = uname;
	}

	public void setPword(String pword) {
		this.pword = pword;
	}
	

}
