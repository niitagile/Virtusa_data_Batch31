package pkg;
import java.sql.*;
public class DBConnection {
	
	public static Connection getConnection(){
		
			Connection con=null;
			//write code here
			try{
				//Class.forName("oracle.jdbc.OracleDriver");
				Class.forName("oracle.jdbc.driver.OracleDriver");
			if(con==null)
				con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hr","hr");
			}catch(Exception e){
				e.printStackTrace();
			}
				return con;
		}

	}


