package com.wipro.candidate.service;

import java.util.ArrayList;
import java.util.Iterator;

import com.wipro.candidate.bean.CandidateBean;
import com.wipro.candidate.dao.CandidateDAO;
import com.wipro.candidate.util.WrongDataException;


public class CandidateMain {

	/**
	 * @param args
	 */
	CandidateDAO candidate;
	public String addCandidate(CandidateBean studBean)
	{
		String result="";
	    //write code here
		try{
			if(studBean==null)
				throw new WrongDataException();
			else{
		int M1=studBean.getM1(),M2=studBean.getM2(),M3=studBean.getM3();
			if(
			studBean.getName().isEmpty()||
			studBean.getName()==null||studBean.getName()==""||
			studBean.getName().length()<2 ||
			
			M1<0 ||M1>100 ||
			M2<0 ||M2>100 ||
			M3<0 ||M3>100 
			)
			throw new WrongDataException();
			candidate=new CandidateDAO();
		studBean.setId(candidate.generateCandidateId(studBean.getName()));
		int total=M1+M2+M3;
		if(total>= 240){
			studBean.setResult("PASS");
			studBean.setGrade("Distinction");
		}
		else
		if(total>=180 && total<240){
			studBean.setResult("PASS");
			studBean.setGrade("First Class");
		}
		else
		if(total>=150 && total<180){
			studBean.setResult("PASS");
			studBean.setGrade("Second Class");
		}
		else
		if(total>=105 && total<150){
			studBean.setResult("PASS");
			studBean.setGrade("Third Class");
			
		}
		else
		if(total<105){
			studBean.setResult("FAIL");
			studBean.setGrade("No Grade");
		}
		//System.out.println(studBean.getGrade());

		candidate.addCandidate(studBean);
		if(total>=105)
			result="PASS";
		else
			result="FAIL";
		//System.out.println(result);
			//	if(result.equals("SUCCESS"))
					result=studBean.getId()+":"+result;
			}
		}
		catch(WrongDataException e){
			result=e.toString();
		}
	    return result;
		
	}
	public ArrayList<CandidateBean> displayAll(String criteria)
	{
		ArrayList<CandidateBean> list=new ArrayList<CandidateBean>();
		try{
			criteria= criteria.toUpperCase();
		if(criteria.equals("PASS")||criteria.equals("FAIL")||criteria.equals("ALL"))
			{
			list=candidate.getByResult(criteria);
			
			}
		else
			throw new WrongDataException();
		
		}
		catch(WrongDataException e){
			//System.out.println(e);
			return null;
			
		}
		
		return list;
		//write code here
		
	}
	public static void main(String[] args) {
		CandidateMain candidateMain=new CandidateMain();
		CandidateBean studbean=new CandidateBean();
		Scanner sc=new Scanner(System.in);
		studBean.setName(sc.nextLine());
		String result = candidateMain.addCandidate(studBean);
		try
		{
			ArrayList<CandidateBean> alist=candidateMain.displayAll("FAIL");
			Iterator <CandidateBean> it=alist.iterator();
			while(it.hasNext())
			{
				CandidateBean c= it.next();
				System.out.println(c.getId()+" "+ c.getName()+" "+c.getResult()+" "+c.getGrade());
			}
			
		}
		catch(NullPointerException e)
		{
			System.out.println("Wrong value select ALL/PASS/FAIL");
			
		}
		System.out.println(result);
	}
}
