package com.wipro.candidate.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.lang.String;

import com.wipro.candidate.bean.CandidateBean;
import com.wipro.candidate.util.DBUtil;


public class CandidateDAO 
{
	public String addCandidate(CandidateBean studentBean)
	{
			//String status="";
			//write code here
			try {
				Connection con=DBUtil.getDBConn();
				String sql="insert into CANDIDATE_TBL values(?,?,?,?,?,?,?)";
				PreparedStatement ps=con.prepareStatement(sql);
				ps.setString(1, studentBean.getId());
				ps.setString(2, studentBean.getName());
				ps.setInt(3, studentBean.getM1());
				ps.setInt(4, studentBean.getM2());
				ps.setInt(5,studentBean.getM3());
				ps.setString(6, studentBean.getResult());
				ps.setString(7, studentBean.getGrade());
				if(ps.execute()) 
				{
					return "SUCCESS";	
				}
				else
				{
					return "FAIL";
				}
			} 
			catch (SQLException e) 
			{
				return "FAIL";
			}
	}
	public ArrayList<CandidateBean> getByResult(String criteria)
	{
				 	 	
		ArrayList<CandidateBean> list=new ArrayList<CandidateBean>();
		ResultSet res=null;
		String sql="";
		try
		{
			Connection con=DBUtil.getDBConn();
			if(criteria.equals("PASS"))
			{
				 sql="select * from CANDIDATE_TBL where Result='PASS'";
				//PreparedStatement ps=con.prepareStatement(sql);
				//res=ps.executeQuery();
			}
			else if (criteria.equals("FAIL"))
			{
				 sql="select * from CANDIDATE_TBL where result='FAIL'";
				//PreparedStatement ps=con.prepareStatement(sql);
				//res=ps.executeQuery();
			}
			else
			{
				 sql="select * from CANDIDATE_TBL";
				
			}
			PreparedStatement ps=con.prepareStatement(sql);
			res=ps.executeQuery();
			while(res.next())
			{
				CandidateBean bean=new CandidateBean();
				bean.setId(res.getString(1));
				bean.setName(res.getString(2));
				bean.setM1(res.getInt(3));
				bean.setM2(res.getInt(4));
				bean.setM3(res.getInt(5));
				bean.setResult(res.getString(6));
				bean.setGrade(res.getString(7));
				list.add(bean);
			}	
			if(list.isEmpty())
			{
				return null;
			}
			else
			{
				return list;
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();	
		}
		return null;
	}
	public String generateCandidateId (String name)
	{
		String id="";
		//write code here
		try {
			id=name.substring(0,2).toUpperCase();
			Connection con=DBUtil.getDBConn();
			ResultSet res;
			Statement st=con.createStatement();
			String sql="select CANDID_SEQ.nextval from dual";
			res=st.executeQuery(sql);
			while(res.next())
			{
				id=id+res.getString(1);
			}
			if(id.length()==6)
			return id;
		
				
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return null;
	}
}